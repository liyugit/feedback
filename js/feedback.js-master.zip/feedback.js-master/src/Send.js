window.Feedback.Send = function() {};
window.Feedback.Send.prototype = {

    send: function() {}

};
